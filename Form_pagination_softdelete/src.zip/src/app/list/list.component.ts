import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Student } from '../form/form.model';

import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  data!: Student[];
  constructor(private router: Router, private employeeService: EmployeeService, private route: ActivatedRoute,
    private dialog: MatDialog) {
  }


 // tutorials: Student[] = [];
   currentTutorial?: Student;
   currentIndex = -1;
   title = '';
   count = 0;
   pageSize = 5;
   pageSizes = [5, 10, 20,50];
   page= 1;

  ngOnInit(): void {
    this.getEmployee();

    // this.retrieveTutorials();
  }


  totalLength: any;
  //show data
  // getEmployee() {
  //   this.employeeService.getEmployeeList().subscribe(data1 => {
  //     this.data = data1

  //     // Pagination
  //     //  this.totalLength.data1.length;
  //   })
  // }

  //delete data
  // deleteEmployee(id: number) {

  //   this.employeeService.deleteEmployee(id).subscribe(data1 => {
  //     console.log(data1);
  //     this.getEmployee();
  //   })
  // }

  //soft delete
  deleteEmployee(raw:any) {
    if(raw.deleted == false){
      raw.deleted=true
    }
    this.employeeService.createEmployee(raw).subscribe(data1 => {
      console.log(data1);
      this.getEmployee();
    })
  }

  //Edit
  updateEmployee(id: number) {
    if (id) {
      this.router.navigate(['/form'], { queryParams: { id: id } });
    }
    else {
      this.router.navigate(['/form']);
    }
  }


  //view 
 
  viewsubject(subject: any,name:any) {
    subject.uname=name
      this.dialog.open(DialogComponent, {
        data: subject
      });
    }

    addForm(){
      this.router.navigate(['/form'])
    }

    //searchbox
    name!: string;
    search() {
      if (this.name == '') {
        this.ngOnInit();
      } else {
        this.data = this.data.filter((res) => {
          return res.name.toLocaleString().match(this.name.toLocaleLowerCase());
        });
      }
    }

    public getRowsValue(flag:any) {
      if (flag === null) {
        return this.data.length;
      } else {
        return this.data.filter(i => (i.state == flag)).length;
      }
   }
  




   getRequestParams( page: number, pageSize:number): any {
    // tslint:disable-next-line:prefer-const
    let params: any = {};
 
    if (page) {
      params[`page`] = page - 1;
    }
    if (pageSize) {
      params[`size`] = pageSize;
    }
    return params;

  }
  getEmployee() {  
      const params = this.getRequestParams(this.page , this.pageSize);
      this.employeeService.getEmployeeList().subscribe(data1 => {
            this.data = data1
          }),
      this.employeeService.getAll(params)
      .subscribe(
        response => {
          const { tutorials, totalItems } = response;
          this.data= tutorials;
          this.count = totalItems;
          console.log(response);
        },
        error => {
          console.log(error);
        });
  }

   handlePageSizeChange(event: any): void {
    this.pageSize = event.target.value;
    this.page = 1;
    this.getEmployee();
  }
  handlePageChange(event: number): void {
    this.page = event;
    this.getEmployee();
  }




}
