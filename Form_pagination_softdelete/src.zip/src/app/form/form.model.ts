export class Student{
    id!:number
    name!:string
    gender!:string
    hobbie!:string
    cars!:string
    address!:string
    date!:string
    file!:File
    deleted!:boolean
   subject=new Array<Subject>();
  state: any

 
}
export class Subject{
     subjectname!:string
    marks!:string
}