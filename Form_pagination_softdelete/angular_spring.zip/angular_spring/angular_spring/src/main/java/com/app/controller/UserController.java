package com.app.controller;

import java.awt.print.Pageable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.management.loading.PrivateClassLoader;

import org.apache.catalina.webresources.EmptyResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.dao.EmpRepo;
import com.app.dao.SubjectRepository;
import com.app.exception.ResourceNotFoundException;
import com.app.helper.FileUploadHelper;
import com.app.model.Emp;
import com.app.model.Subject;
import com.app.service.EmpService;

@RestController
@RequestMapping("/api/v1/")

@CrossOrigin
public class UserController {

	@Autowired
	private EmpRepo employeeRepository;
	
	@Autowired
	private EmpService empService;
	
	
	@Autowired
	private SubjectRepository subjectRepository;
	
	
	//get all employees
	@GetMapping("/emp")
	public List<Emp> getAllEmployees(){
		
	
		List<Emp> emp = empService.getmyEmp();
		
		return emp;
	}
	//get all employees pagination
	  @GetMapping("/emp/page")
	  public Page<Emp> list(@RequestParam(name = "page") int page,
	                            @RequestParam(name = "size") int size) {
	    PageRequest pageRequest = PageRequest.of(page, size);
	    Page<Emp> pageResult = employeeRepository.findAll(pageRequest);

	      return pageResult;
	
	  }

		
	//create emp rest api
		@PostMapping("/emp")
		public ResponseEntity<Emp> createEmployee(@RequestBody Emp employee) {
	
//			return employeeRepository.save(employee);
			return new ResponseEntity<Emp>(empService.saveEmp(employee),HttpStatus.OK);
		}
		
		
	//get emp id rest api
		@GetMapping("/emp/{id}")
		public ResponseEntity<Emp> getEmployeeById(@PathVariable int id) {
			Emp employee =employeeRepository.findById(id)
					.orElseThrow(()->new ResourceNotFoundException("employee not exists with id"));
			return ResponseEntity.ok(employee);
		}
		
	//update emp rest api
		@PutMapping("/emp/{id}")
		public ResponseEntity<Emp> updateEmployee(@PathVariable("id") int id,@RequestBody Emp employeeupdate){
			
		
			return new ResponseEntity<Emp>(empService.updateEmp(id, employeeupdate),HttpStatus.OK);
	}
		
		//Delete empoyee rest api
		@DeleteMapping("/emp/{id}")
		public ResponseEntity<String> deleteEmployee(@PathVariable int id){
			empService.deleteEmp(id);
			return new ResponseEntity<String>("deleted succesfully",HttpStatus.OK);
		}


		
	//DeleteSubject
		@DeleteMapping("/subject/{subjectId}")
		
		public ResponseEntity<Map<String, Boolean>> delete(@PathVariable("subjectId") int subjectId){
			Subject subject =subjectRepository.findById(subjectId)
					.orElseThrow(()->new ResourceNotFoundException("employee not exists with id"));
			subjectRepository.deleteById(subjectId);
			Map<String,Boolean> response =new HashMap<>();
			response.put("deleted",Boolean.TRUE );
			return ResponseEntity.ok(response);	
	}
		
}
		
		

